---
name: understand
description: 이 프로젝트(배터리 셀 생산·운송 계획 시뮬레이터)의 코드 흐름과 파일별 역할을 탭·인터랙티브 HTML 가이드로 보여 준다. 코드 이해, 온보딩, 구조 설명을 요청받거나 /understand 를 입력했을 때 사용한다.
---

# /understand — 코드 이해 가이드

프로젝트 전체 흐름과 코드별 역할을 시각화한 **단일 HTML 파일**을 안내·갱신한다.

- 산출물: `docs/understand/basic_guide.html` (외부 의존성 없는 자체 완결형 HTML, 인라인 SVG/CSS/JS)

## 절차 (호출할 때마다 항상 새로 생성한다)

기존 `docs/understand/basic_guide.html` 이 있든 없든 **매번 다시 생성(덮어쓰기)** 한다. 사용자가 지우거나 옮겨도 다음 호출 때 다시 만들어진다.

1. `docs/understand/` 폴더가 없으면 만든다. 그 안의 다른 파일·폴더(사용자가 옮긴 사본 등)는 건드리지 않는다.
2. 이 스킬 폴더의 `template.html` 을 `docs/understand/basic_guide.html` 로 복사한다 (이미 있으면 덮어쓴다).
   - Windows PowerShell 예: `New-Item -ItemType Directory -Force docs\understand; Copy-Item .claude\skills\understand\template.html docs\understand\basic_guide.html -Force`
3. 복사한 `basic_guide.html` 을 현재 코드와 대조해 어긋난 곳을 고친다 ("점검 대상" 참고). `CLAUDE.md`(있다면)와 `src/main/java/com/example/demo`, `src/main/resources` 를 기준으로 한다.
   - 변경 확인: `git ls-files src` 와 `git diff --stat` / `git log` 로 파일 목록·줄 수가 템플릿과 다른지 본다.
   - 어긋남이 없으면 수정 없이 넘어간다.
   - 가이드를 고쳤다면 `template.html` 에도 같은 수정을 반영해, 다음 호출이 최신 상태에서 시작하게 한다.
4. 브라우저로 연다 (Windows: `Start-Process docs\understand\basic_guide.html`, 인자가 있으면 `#해시` 포함).
5. 사용자에게 파일 경로와 코드와 달라서 고친 곳(없으면 "변경 없음")을 한두 줄로 알려 준다.

`template.html` 이 없으면 아래 "탭 구성"대로 처음부터 만든 뒤 `template.html` 로도 저장한다.

인자가 있으면(`/understand planner` 등) 해당 주제의 탭을 먼저 열도록 URL 해시(`#planner`)를 붙여 안내한다.

## 탭 구성 (해시 = 탭 id)

| 탭 | 해시 | 내용 | 인터랙션 |
|---|---|---|---|
| 전체 흐름 | `#flow` | 브라우저 → 인터셉터 → 컨트롤러 → 서비스 → Planner → DB 요청 흐름 | 시나리오 선택(시뮬레이션/확정/상태 변경), 단계 이전·다음·자동 재생 |
| 코드 지도 | `#map` | 레이어별 파일 역할 | 파일 카드 클릭 시 상세(역할, 핵심 메서드, 줄 수), 레이어 필터 |
| Planner | `#planner` | 경로 계산 규칙과 3가지 옵션 | 나라별 주문량 슬라이더 → 방문 횟수·재고 그래프·생산비 실시간 계산 |
| 데이터 모델 | `#data` | 엔티티 관계도, 주문 상태 전이 | 엔티티 클릭 시 필드, 상태 클릭 시 가능한 전이 |
| 화면·프론트 | `#front` | 템플릿 ↔ JS ↔ API 연결 | 화면 선택 시 연결 강조 |
| 설계 포인트 | `#design` | 서버 재계산, 버전 충돌, 스냅샷, 낙관적 잠금 | 충돌 시나리오 체험 버튼 |

키보드 ←/→ 로 탭 이동, 마지막으로 연 탭은 URL 해시로 유지한다.

## 작성 규칙

- 한국어, 들여쓰기는 탭이 아니라 공백 2칸(HTML 파일 한정).
- 외부 CDN·이미지·폰트를 쓰지 않는다 (오프라인에서 열려야 한다). 도형은 인라인 SVG, 색은 CSS 변수.
- 다크/라이트 모두 `prefers-color-scheme` 로 대응한다.
- 수치·규칙은 코드에서 가져온다. 기본 마스터 값은 `BatteryService.initDefaults()`, 알고리즘 규칙은 `Planner` 클래스 Javadoc 이 기준이다.
- 코드를 그대로 길게 복사하지 않는다. 클래스·메서드 이름과 한 줄 역할 위주로 쓴다.

## 점검 대상 (코드 변경 시 가이드를 고쳐야 하는 곳)

- 파일 추가/삭제/이름 변경 → `#map` 탭 데이터
- 엔드포인트 추가/변경 (`AppController`) → `#flow`, `#front`
- 엔티티·상태 전이 변경 (`entity/`, `OrderStatus.next()`) → `#data`
- `Planner` 규칙·상수 변경, 마스터 기본값 변경 → `#planner` (계산기 기본값 포함)
